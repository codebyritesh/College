import Course from "./component/Basics/Course";


function App() {
  return (
   <>
   
   
   <Course />
   
   </>
  );
}

export default App;
