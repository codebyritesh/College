import React from 'react'

const Invoice = () => {
  return (
    <>
    
    <h1>Hello World</h1>
    
    </>
  )
}

export default Invoice