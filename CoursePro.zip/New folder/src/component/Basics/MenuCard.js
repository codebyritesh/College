import React from "react";
import Invoice from "./Invoice";



const MenuCard = ({menuData}) => {
    // console.log(menuData)

  const loadScript = (src) =>{
      return new Promise((resolve)=>{
        const script = document.createElement('script')
        script.src = src

        script.onload = () =>{
          resolve(true)
        }

        script.onerror = () => {
          resolve(false)
        }

        document.body.appendChild(script)
      })
  }

  const displayPayment = async (amount) =>{
    
    const res = await loadScript('https://checkout.razorpay.com/v1/checkout.js')

    if(!res){
      alert("You Are Offline. Please connect with internet!!!")
      return
    }


    const options = {
      key: "rzp_test_Y5mCxP51hSKMyz",
      currency: "INR",
      amount:amount*100,
      name:"MGM EVENTS",
      description:"Thanks for enrolling",
      
      handler: (response)=>{
        // alert(response.razorpay_payment_id)
        // alert(response.razorpay_payment_id)
        alert("Payment Successfull")
      },
      prefill:{
        name:""
      }

      

    }

    const paymentObject = new window.Razorpay(options)
    paymentObject.open()

  }


  return (
      <>
        <section className="main-card--cointainer">
      {menuData.map((curElem) => {

        const{id,name,image,description,price} = curElem

          return(
          <>
            <div className="card-container" key={id}>
              <div className="card">
                <div className="card-body">
                  <span className="card-number card-circle subtle">{id}</span>
                  {/* <span className="card-author subtle">{category}</span> */}
                  <img src={image} alt="images" className="card-media" />
                  <h2 className="card-title">{name}</h2>
                  <span className="did">₹ {price}</span>
                  
                  <span className="card-description subtle">
                  {description}
                  </span>
                  <div className="card-read"></div>
                  
                  <span className="card-tag button-26" onClick={()=> displayPayment(price)}>Buy Now</span>
                </div>
              </div>
            </div>
        </>
        );
      })};
      </section>
    </>
  );
};

export default MenuCard;
