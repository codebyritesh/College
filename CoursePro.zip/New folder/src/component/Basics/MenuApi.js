const Menu = [
  {
    id: 1,
    image: "images/mern.jpg",
    name: "MERN Stack",
    category: "Web Development",
    price: 1200,
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in .",
  },

  {
    id: 2,
    image: "images/blockchain.jpg",
    name: "Block Chain Development",
    category: "Blockchain Development",
    price: 199,
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 3,
    image: "images/aiml.jpg",
    name: "AI/ML Development",
    category: "AI/ML Development",
    price: 999,
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 4,
    image: "../images/andapp.jpg",
    name: "Android App Development",
    category: "Android Development",
    price: 999,
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 5,
    image: "../images/iosapp.jpg",
    name: "Ios App Development",
    category: "IOS Development",
    price: 10,
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 6,
    image: "../images/frontend.jpg",
    name: "Front-End Development",
    category: "Web Development",
    price: 500,
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 7,
    image: "../images/backend.jpg",
    name: "Back-End Development",
    category: "Web Development",
    price: 9000,
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 8,
    image: "../images/fullstack.jpg",
    name: "Full-Stack Development",
    category: "Web Development",
    price: 46000,
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 9,
    image: "../images/datascience.jpg",
    name: "Data Science",
    category: "Data Science",
    price: 99,
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
];

export default Menu;
